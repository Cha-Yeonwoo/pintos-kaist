#include <stdio.h>
#include "tests/threads/tests.h"

void test_hello(void) {
    printf("hello, world!\n");
}
